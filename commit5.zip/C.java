public class C {

    private String c = "test";

    private String f = "init";

    public byte oo() {
        return 1;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object rr() {
        return null;
    }

    public Object pp() {
        return this;
    }
}
