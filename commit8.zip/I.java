public interface I {

    void ab();

    int cc();
}
