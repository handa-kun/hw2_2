public interface D {

    int af();

    String kk();
}
