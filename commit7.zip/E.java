public interface E {

    java.util.List<String> jj();

    void bb();
}
