public class C extends null {

    private String c = "test";

    private String f = "init";

    public byte oo() {
        return 1;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object rr() {
        return null;
    }

    public Object pp() {
        return this;
    }

    public int cc() {
        return 42;
    }

    public int af() {
        return -1;
    }

    public void ab() {
        System.out.println("\n");
    }

    public float ff() {
        return 3.14;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void aa() {
        return;
    }
}
