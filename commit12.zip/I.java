public class I extends null {

    void ab();

    int cc();
}
