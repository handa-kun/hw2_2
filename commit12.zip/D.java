public class D extends null {

    int af();

    String kk();
}
