public class D extends null {

    int af();

    String kk();

    public void aa() {
        return;
    }
}
