public class E extends null {

    java.util.List<String> jj();

    void bb();

    public int cc() {
        return 42;
    }
}
