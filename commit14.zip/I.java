public class I extends null {

    void ab();

    int cc();

    public int af() {
        return -1;
    }
}
